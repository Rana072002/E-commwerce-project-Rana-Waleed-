import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';

class ForgotPassworedPageVerfication extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    //TODO: implement createState
    throw UnimplementedError();

  }
}